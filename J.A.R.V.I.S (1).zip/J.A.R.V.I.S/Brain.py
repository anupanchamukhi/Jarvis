import pyttsx3
import speech_recognition as sr
import os
import webbrowser
import time
import random
import pywhatkit
import webbrowser
import wikipedia
import datetime
import pyautogui
from selenium import webdriver
import pyautogui as p
import win32com.client
from drawings import doDraw
from nlpchatbot import nlp
from image_pop import imgPop
#pip install sapi5
#pip install speechRecognition
#pip install PyAudio -- given by chatgpt
#pip install wikipedia
#pip install pywhatkit
#pip install googletrans



engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
#print(voices[1].id)
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate',200)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    speak("Jai shree ram ")
    speak("How can I help you ma'am?")

def takeCommand():
    #It takes microphone input from the user and returns string output
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 0.5
        r.energy_threshold = 300 
        #seconds of non spekaing audio before a  phrase is considered compelete
        audio =  r.listen(source)

    try:
        print("Recognizing.....")
        query = r.recognize_google(audio, language='en-in')
        print("User said :", query,"\n")  #*


    except Exception as e:
        print(e)
        print("Say that again please......")
        return "None"
    return query

def chromefun():
    speak("opening chrome")
    driver = webdriver.Chrome().lower()
    try:
        while True:
            command = takeCommand()

            if command is not None:
                if "open new tab" in command:
                    driver.execute_script("window.open('');")
                elif "close tab" in command:
                    driver.close()
                elif "delete tab" in command:
                    tab_number = int(command.split("delete tab", 1)[1].strip())
                    handles = driver.window_handles
                    if tab_number >= 0 and tab_number < len(handles):
                        driver.switch_to.window(handles[tab_number])
                        driver.close()
                    else:
                        speak("Invalid tab number.")
                # Add more commands here...
                elif "search" in command:
                    query = command.split("search", 1)[1].strip()
                    driver.get(f"https://www.google.com/search?q={query}")
                elif "exit chrome" in command:
                    speak("closing chrome")
                    return 0
                    break
                elif "refresh" in command:
                    driver.refresh()

                elif "take screenshot" in command:
                    take_screenshot()

                elif 'you need a break' in command:
                    return 1


            time.sleep(2)  # To avoid recognizing the same command repeatedly

    finally:
        driver.quit()
        return 0

def OpenApps():
    if 'open my folder' in query:
        folder_path = "d:\\aishu"
        speak("opening folder")
        os.startfile(folder_path)

    elif 'open vs code' in query:
        vs_path="C:\\Users\\Admin\\Desktop\\Visual Studio Code.lnk"
        speak("opening visual studio code")
        os.startfile(vs_path)

    elif 'open youtube' in query:
        speak("opening Youtube")
        webbrowser.open("youtube.com")

    elif 'open google' in query:
        speak("opening google")
        webbrowser.open("google.com")

    elif 'open gmail' in query:
        speak("opening gmail")
        webbrowser.open("gmail.com")

    elif 'open paint' in query:
        speak("opening ms paint")
        os.system("start mspaint")

    elif 'open settings' in query:
        speak("opening settings")
        os.system("start ms-settings:")

    elif 'open camera' in query:
        speak("opening camera")
        os.system("start microsoft.windows.camera:")

    elif 'open calculator' in query:
        speak("opening calculator")
        os.system("start calc")

    elif 'open calendar' in query:
        speak("opening out look calendar")
        os.system("start outlookcal:")

    elif 'open clock' in query:
        speak("opening clockr")
        os.system("start ms-clock:")

    elif 'open whatsapp' in query:
        speak("opening whatsapp")
        os.system("start whatsapp:")

    elif 'open ms excel' in query:
        speak("opening excel")
        os.system("start excel")

    elif 'open powerpoint' in query:
        speak("opening powerpoint")
        os.system("start powerpnt")

def CloseApps():
    if 'close vs code' in query:
        speak("closing  visual studio code")
        os.system("TASKKILL /F /im code.exe")

    elif 'close youtube' in query:
        speak("closing Youtube")
        os.system("TASKKILL /F /im msedge.exe")

    elif 'close google' in query:
        speak("closing google")
        os.system("TASKKILL /F /im chrome.exe")

    elif 'close gmail' in query:
        speak("closing gmail")
        os.system("TASKKILL /F /im msedge.exe")

    elif 'close paint' in query:
        speak("closing  ms paint")
        os.system("TASKKILL /F /im mspaint.exe")

    elif 'close settings' in query:
        speak("closing settings")
        os.system("TASKKILL /F /im SystemSettings.exe")

    elif 'close camera' in query:
        speak("closing camera")
        os.system("TASKKILL /F /im WindowsCamera.exe")

    elif 'close calculator' in query:
        speak("closing calculator")
        os.system("TASKKILL /F /im Calculator.exe")

    elif 'close calendar' in query:
        speak("closing calendar")
        os.system("TASKKILL /F /im HxCalendarAppImm.exe")

    elif 'close clock' in query:
        speak("closing clock")
        os.system("TASKKILL /F /im ApplicationFrameHost.exe")  # Assuming default Windows clock

    elif 'close whatsapp' in query:
        speak("closing whatsapp")
        os.system("TASKKILL /F /im whatsapp.exe")

    elif 'close ms excel' in query:
        speak("closing ms excel")
        os.system("TASKKILL /F /IM excel.exe")

    elif 'close powerpoint' in query:
        speak("closing powerpoint")
        os.system("TASKKILL /F /IM powerpnt.exe")

def take_screenshot():
    # Create a directory named "screenshots" if it doesn't exist
    folder_name = 'screenshots'
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    # Specify the file name (you can customize this)
    file_name = os.path.join(folder_name, f'screenshot.png')

    # Take a screenshot
    screenshot = pyautogui.screenshot()

    # Save the screenshot
    screenshot.save(file_name)

    print(f"Screenshot captured")

def open_notepad():
    notepad_open = p.getActiveWindow().title == "Untitled - Notepad"
    if not notepad_open:
        p.press('win')
        p.write('notepad')
        time.sleep(3)
        p.press('enter')
        time.sleep(3)

def notefun():
    speak("opening notepad")
    notepad_open = False
    
    while not notepad_open:
        # Check if Notepad is open
        notepad_open = p.getActiveWindow().title == "Untitled - Notepad"
        
        if not notepad_open:
            print("Notepad is not open. Trying to open...")
            open_notepad()
        else:
            print("Notepad is open.")
            break

    while True:
        cmd = takeCommand()
        if "close notepad" in cmd:
            p.hotkey('alt', 'f4')
            speak("closing notepad")
            return 0
            break
        elif cmd == "save notepad":
            p.hotkey('ctrl', 's')
        elif "write" in cmd:
            # Extracting the text to write after the "write" command
            text_to_write = cmd.split("write", 1)[-1].strip()
            p.write(text_to_write)
            p.press('enter')
        elif cmd == "backspace":
            p.press('backspace')
        elif 'you need a break' in cmd:
            return 1
        else:
            print("Invalid command. Please try again.")

def open_word():
    while True:
        try:
            word_app = win32com.client.Dispatch("Word.Application")
            word_app.Visible = True  # Make Word visible
            word_app.WindowState = 3  # Maximize Word window
            time.sleep(1)  # Introduce a short delay
            shell = win32com.client.Dispatch("WScript.Shell")
            shell.AppActivate("Microsoft Word")  # Focus on Word window
            print("Word opened successfully!")
            return word_app
        except Exception as e:
            print(f"Failed to open Word: {e}. Retrying in 5 seconds...")
            time.sleep(5)

def wordfun():
    speak("opening word")
    word_app = open_word()
    doc = word_app.Documents.Add()

    try:
        while True:
            command = takeCommand()

            if command is None:
                continue

            if "write" in command:
                content = command.split("write", 1)[1].strip()
                word_app.Selection.TypeText(content + " ")
            elif "new paragraph" in command:
                word_app.Selection.TypeParagraph()
            elif "save" in command:
                doc.SaveAs("your_document.docx")
            elif "close" in command:
                doc.SaveAs("your_document.docx")
                speak("closing word")
                return 0
                break
            elif 'you need a break' in command:
                return 1
            # Add other command cases here...
            else:
                print("Command not recognized. Try again.")

    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        doc.Close()
        word_app.Quit()

def open_gmail():
    speak("opening gmail")
    webbrowser.open("https://mail.google.com")
    # Wait for Gmail to load
    time.sleep(5)  # Adjust this delay as needed
    # Look for the compose button and click it
    compose_button_pos = pyautogui.locateOnScreen('image.png')
    if compose_button_pos:
        pyautogui.click(compose_button_pos)

def compose_and_send():
    pyautogui.click(100, 200)  # Adjust these coordinates based on your screen resolution
    time.sleep(2)
    speak("Enter receiver's name: ")
    emailsaddr = {"aishwarya": "a.maharajpet@gmail.com", "ananya": "aishu.c.m.2019@gmail.com"}
    while True:
        inp = takeCommand().lower().strip()
        print("Input:", inp)
        print("Emails:", emailsaddr)
        receiver_email = emailsaddr.get(inp)
        if receiver_email:
            pyautogui.write(receiver_email)
            pyautogui.press('tab')
            pyautogui.press('tab')
            time.sleep(2)
            break
        else:
            speak("Receiver's email not found.")
    speak("Enter subject: ")
    subject = ""
    while True:
        word = takeCommand().lower().strip()
        if word == "none":
            break
        elif word == "backspace" and len(subject) > 0:
            pyautogui.press('backspace')
            subject = subject[:-1]
        elif "next" in word:
            pyautogui.press('tab')
            speak("Enter body: ")
            body = ""
            while True:
                word = takeCommand().lower().strip()
                if word == "none":
                    break
                elif word == "backspace" and len(body) > 0:
                    pyautogui.press('backspace')
                    body = body[:-1]
                elif "send" in word:
                    pyautogui.press('tab')
                    pyautogui.press('enter')
                    return
                else:
                    body += word + " "
                    pyautogui.write(word)
                    pyautogui.press('space')
                    break
        elif "send" in word:
            pyautogui.press('tab')
            pyautogui.press('enter')
            return
        else:
            subject += word + " "
            pyautogui.write(word)
            pyautogui.press('space')

if __name__ == "__main__":
    imgPop()
    wishMe()
    flag=0
    retval=0
    while True:
        query = takeCommand().lower()  #lower matches query efficienty ignoring case sensitivity in voice query
        #logic for execting tasks based on query
        if 'you need a break' in query or retval==1:
            speak("ok ma'am, if you need me, I'm just a command away!")
            speak("Just say wake up jarvis")
            break

        if 'wikipedia' in query:
            query = query.replace("wikipedia","")
            query = query.replace("search","")
            if query != "" and query!=" ":
                speak('Searching Wikipedia.....')
                results = wikipedia.summary(query, sentences=2)
                speak("According to wikipedia")
                print(results)
                speak(results)
            else:
                speak("please say the query again!")

        elif 'play music' in query or 'song' in query:
            speak("Playing music")
            music_dir = 'songs'
            songs = os.listdir(music_dir)
            print(songs)
        #can add additional feature of detecting mp3
        #os.startfile(os.path.join(music_dir, songs[0])) # can use random module
            random_song = random.choice(songs)
            os.startfile(os.path.join(music_dir, random_song))

        elif 'the time' in query:
            strTime =datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"ma'am, the time is {strTime}")

        elif 'youtube search' in query:
            speak("Here is what I found")
            query = query.replace("jarvis","")
            query = query.replace("youtube search","")
            query=query.strip()
            query = query.replace(" ","+")
            web='https://www.youtube.com/results?search_query='+query
            webbrowser.open(web)

        elif 'google search' in query:
            speak("Here is what I found")
            query = query.replace("jarvis","")
            query = query.replace("google search","")
            query=query.strip()
            pywhatkit.search(query)

        elif 'website' in query:
            speak("Here is what i found")
            query = query.replace("jarvis","")
            query = query.replace("website","")
            query = query.replace("open","")
            query=query.strip()
            web='https://www.'+query+'.com'
            webbrowser.open(web)

        elif 'notepad' in query:
            retval=notefun()
        elif 'screenshot' in query:
            take_screenshot()
        elif 'open chrome' in query:
            retval=chromefun()
        elif 'open word' in query:
            retval=wordfun()
        elif 'mail' in query:
            open_gmail()
            compose_and_send()
        elif 'open ' in query:
            OpenApps()
        elif 'close ' in query:
            CloseApps()
        elif 'draw ' in query:
            doDraw(query)
        if 'switch on conversations' in query:
            flag = 1
            speak("Conversations switched on.")
        elif 'switch off conversations' in query:
            flag = 0
            speak("Conversations switched off.")
        elif 'conversation is on'in query:
            if flag == 1:
                speak("conversations are active")
            else:
                speak("negative, conversations are not active")
        else:
            if flag == 1:
                ret = nlp(query)
                speak(ret)
            else:
                print("Flag is not set to 1.")