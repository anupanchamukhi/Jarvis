from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.video import Video
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
from SampleGeneratorAndModelTrainer import reg
from FaceRecognition import auth
import sys

class Mylayout(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Add Video widget instead of AsyncImage
        self.video = Video(source='intro1.mp4', state='play', options={'eos': 'loop'})
        self.video.size_hint = (None, None)  # Disable size_hint
        self.video.size = (500, 500)  # Set fixed size for the video
        self.video.pos_hint = {'center_x': 0.5, 'center_y': 0.5}  # Align video to center
        self.add_widget(self.video)

        self.label = Label(text="Welcome, Please authorize yourself to Login", font_size='20sp', size_hint=(None, None), size=(500, 50), pos_hint={'center_x': 0.5, 'y': 0.9})
        self.add_widget(self.label)

        self.Register = Button(text="Register new user", background_color=(0.1294, 0.5725, 0.6980, 1), size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.3, 'y': 0.1})
        self.Register.bind(on_press=self.Register_funct)
        self.add_widget(self.Register)
   
        self.login = Button(text="Login", background_color=(0.1294, 0.5725, 0.6980, 1), size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.7, 'y': 0.1})
        self.login.bind(on_press=self.login_funct)
        self.add_widget(self.login)
        
    
    def Register_funct(self, instance):
        reg()

    def login_funct(self, instance):
        auth()
        sys.exit()

class MyKivyApp(App):
    def build(self):
        Window.clearcolor = (0, 0, 0, 0)
        return Mylayout()

if __name__ == "__main__":
    MyKivyApp().run()
