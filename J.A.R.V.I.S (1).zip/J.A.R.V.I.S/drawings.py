import turtle

# Function to draw a square
def draw_square(t):
    for _ in range(4):
        t.forward(100)  # Move forward by 100 units
        t.right(90)     # Turn right by 90 degrees

# Function to draw a triangle
def draw_triangle(t):
    for _ in range(3):
        t.forward(100)  # Move forward by 100 units
        t.left(120)     # Turn left by 120 degrees

# Function to draw a circle
def draw_circle(t):
    t.circle(50)  # Draw a circle with a radius of 50 units


def draw_rectangle(width, height,t):
    for _ in range(2):
        t.forward(width)  # Move forward by the specified width
        t.left(90)        # Turn left by 90 degrees
        t.forward(height) # Move forward by the specified height
        t.left(90)        # Turn left by 90 degrees

# Function to draw a rose
def draw_rose(t):
    t.penup ()
    t.left (90)
    t.fd (200)
    t.pendown ()
    t.right (90)
 

    t.fillcolor ("red")
    t.begin_fill ()
    t.circle (10,180)
    t.circle (25,110)
    t.left (50)
    t.circle (60,45)
    t.circle (20,170)
    t.right (24)
    t.fd (30)
    t.left (10)
    t.circle (30,110)
    t.fd (20)
    t.left (40)
    t.circle (90,70)
    t.circle (30,150)
    t.right (30)
    t.fd (15)
    t.circle (80,90)
    t.left (15)
    t.fd (45)
    t.right (165)
    t.fd (20)
    t.left (155)
    t.circle (150,80)
    t.left (50)
    t.circle (150,90)
    t.end_fill ()
 

    t.left (150)
    t.circle (-90,70)
    t.left (20)
    t.circle (75,105)
    t.setheading (60)
    t.circle (80,98)
    t.circle (-90,40)

    t.left (180)
    t.circle (90,40)
    t.circle (-80,98)
    t.setheading (-83)

    t.fd (30)
    t.left (90)
    t.fd (25)
    t.left (45)
    t.fillcolor ("dark green")
    t.begin_fill ()
    t.circle (-80,90)
    t.right (90)
    t.circle (-80,90)
    t.end_fill ()
    t.right (135)
    t.fd (60)   
    t.left (180)
    t.fd (85)
    t.left (90)
    t.fd (80)
 
    t.right (90)
    t.right (45)
    t.fillcolor ("dark green")
    t.begin_fill ()
    t.circle (80,90)
    t.left (90)
    t.circle (80,90)
    t.end_fill ()
    t.left (135)
    t.fd (60)
    t.left (180)
    t.fd (60)
    t.right (90)
    t.circle (200,60)


# Function to draw a sun
def draw_sun(t):
    t.penup()
    t.goto(0, 100)  # Move to the starting position for the sun
    t.pendown()
    t.color("yellow")  # Set the color of the sun to yellow
    t.begin_fill()
    t.circle(50)  # Draw a circle for the sun
    t.end_fill()

# Function to draw a cloud
def draw_cloud(x, y, radius, color,t):
  t.penup()
  t.goto(x, y)
  t.pendown()
  t.color(color, color)
  t.begin_fill()
  for i in range(6):
    t.circle(radius)
    t.left(60)
  t.end_fill()

# Function to draw a boat
def draw_boat(t):
    t.color("black","orange")
    t.penup()
    t.goto(-100,-150)
    t.begin_fill()
    t.pendown()
    t.forward(200)
    t.left(60)
    t.forward(80)
    t.setheading(180)
    t.forward(280)
    t.left(120)
    t.forward(80)
    t.end_fill()
    t.backward(80)
    t.setheading(0)
    t.forward(140)
    t.left(90)
    #Draw the stick of the boat
    t.pensize(8)
    t.forward(125)
    t.backward(5)
    t.penup()
    #draw the white left wings of the boat
    t.pensize(2)
    t.pendown()
    t.left(130)
    t.forward(4)
    t.color("grey")
    t.begin_fill()
    t.forward(165)
    t.setheading(0)
    t.forward(125)
    t.end_fill()
    t.penup()
    t.left(90)
    t.forward(108)
    t.right(90)
    t.forward(7)

    #draw the right white wing of the boat
    t.pensize(2)
    t.pendown()
    t.right(40)
    t.color("grey")
    t.begin_fill()
    t.forward(168)
    t.setheading(180)
    t.forward(125)
    t.end_fill()
    t.penup()


# Function to draw a tree
def draw_tree(t):
    t.color("green")
    t.pensize(5)
    t.begin_fill()
    t.forward(100)
    t.left(150)
    t.forward(90)
    t.right(150)
    t.forward(60)
    t.left(150)
    t.forward(60)
    t.right(150)
    t.forward(40)
    t.left(150)
    t.forward(100)
    t.end_fill()
    t.begin_fill()
    t.left(60)
    t.forward(100)
    t.left(150)
    t.forward(40)
    t.right(150)
    t.forward(60)
    t.left(150)
    t.forward(60)
    t.right(150)
    t.forward(90)
    t.left(150)
    t.forward(133)
    t.end_fill()
    t.color("brown")
    t.pensize(1)
    t.begin_fill()
    t.right(90)
    t.forward(80)
    t.right(90)
    t.forward(40)
    t.right(90)
    t.forward(80)
    t.end_fill()

def draw_star(size,t):
    for _ in range(5):
        t.forward(size)  # Move forward by the specified size
        t.right(144)     # Turn right by 144 degrees

def doDraw(query):
    # Create a turtle object
    t = turtle.Turtle()

    # Set the turtle's speed
    t.speed(1)  # You can adjust the speed (1-10) to control how fast the turtle moves

    if 'square' in query:
        draw_square(t)

    elif 'circle' in query:
        draw_circle(t)

    elif 'triangle' in query:
        draw_triangle(t)

    elif 'rectangle' in query:
        draw_rectangle(200,100,t)

    elif 'rose' in query:
        # Set up the turtle graphics window
        t.speed(10)
        draw_rose(t)

    elif 'boat' in query:
        # Set up the turtle graphics window
        turtle.bgcolor("skyblue")  # Set the background color to light blue
        t.speed(5)
        draw_boat(t)

    elif 'tree' in query:
        # Set up the turtle graphics window
        turtle.bgcolor("skyblue")  # Set the background color to light blue
        t.speed(10)
        draw_tree(t)

    elif 'cloud' in query:
        # Set up the turtle graphics window
        turtle.bgcolor("skyblue")
        t.speed(10)
        draw_cloud(0, 0, 50, "white",t)
        draw_cloud(-100, 50, 40, "white",t)
        draw_cloud(100, 50, 40, "white",t)

    elif 'sun' in query:
        # Set up the turtle graphics window
        turtle.bgcolor("skyblue")
        draw_sun(t)

    elif 'star' in query:
    # Set up the turtle graphics window
        turtle.bgcolor("black")  # Set background color
        t.color("yellow")       # Set the star's color
        t.speed(1)               # Set the turtle's speed (1-10)
        draw_star(100,t)


    turtle.exitonclick()