import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import json
import random
from sklearn.naive_bayes import MultinomialNB

# Ensure to download necessary NLTK resources if not already downloaded
# nltk.download('punkt')
# nltk.download('wordnet')

def preprocess_text(text):
    lemmatizer = WordNetLemmatizer()
    tokens = word_tokenize(text)
    tokens = [lemmatizer.lemmatize(word.lower()) for word in tokens]
    return tokens

def train_classifier(intents):
    # Create training data
    training_data = []
    for intent in intents['intents']:
        for pattern in intent['patterns']:
            tokens = preprocess_text(pattern)
            training_data.append((tokens, intent['tag']))

    # Create a bag of words
    all_words = [token for pattern, _ in training_data for token in pattern]
    all_words = list(set(all_words))

    # Create a training set
    X_train = []
    y_train = []
    for pattern, intent in training_data:
        bag = [1 if word in pattern else 0 for word in all_words]
        X_train.append(bag)
        y_train.append(intent)

    # Train a simple classifier
    classifier = MultinomialNB()
    classifier.fit(X_train, y_train)
    return classifier, all_words

def get_response(classifier, all_words, query, intents):
    input_tokens = preprocess_text(query)
    input_bag = [1 if word in input_tokens else 0 for word in all_words]
    intent = classifier.predict([input_bag])[0]

    for i in intents['intents']:
        if i['tag'] == intent:
            response = random.choice(i['responses'])
            return response

def nlp(query):
    # Load intent data from JSON
    with open('intents.json') as file:
        intents = json.load(file)

    classifier, all_words = train_classifier(intents)
    response = get_response(classifier, all_words, query, intents)
    return response
