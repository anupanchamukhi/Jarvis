from PIL import Image, ImageTk
import tkinter as tk
import os

class ImageDisplay(tk.Tk):
    def __init__(self, image_path):
        tk.Tk.__init__(self)

        # Load the image
        self.image = Image.open(image_path)
        self.photo = ImageTk.PhotoImage(self.image)

        # Create a label to display the image
        self.label = tk.Label(self, image=self.photo)
        self.label.pack(expand=True, anchor=tk.CENTER)

        # Schedule the image to close after 10 seconds
        self.after(1000, self.close_image)

    def close_image(self):
        self.destroy()

def imgPop():
    # Specify the path to your image file
    image_path = "JARVIS 2.png"

    # Check if the image file exists
    if os.path.exists(image_path):
        app = ImageDisplay(image_path)
        app.mainloop()
    else:
        print(f"Error: Image file '{image_path}' not found.")
