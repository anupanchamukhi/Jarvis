import subprocess
import speech_recognition as sr
import pyttsx3
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.video import Video
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
engine.setProperty('rate', 200)
global brain_process
brain_process = None

class Mylayout(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        self.video = Video(source='intro1.mp4', state='play', options={'eos': 'loop'})
        self.video.size_hint = (None, None)
        self.video.size = (500, 500)
        self.video.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        self.add_widget(self.video)

        self.label = Label(text="Manual override", font_size='40sp', size_hint=(None, None), size=(500, 50), pos_hint={'center_x': 0.5, 'y': 0.9})
        self.add_widget(self.label)

        self.start = Button(text="Start Jarvis", background_color=(0.1294, 0.5725, 0.6980, 1), size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.3, 'y': 0.1})
        self.start.bind(on_press=self.start_funct)
        self.add_widget(self.start)
   
        self.stop = Button(text="Stop Jarvis", background_color=(0.1294, 0.5725, 0.6980, 1), size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.5, 'y': 0.1})
        self.stop.bind(on_press=self.stop_funct)
        self.add_widget(self.stop)
        
        self.KillCode = Button(text="Kill code", background_color=(0.1294, 0.5725, 0.6980, 1), size_hint=(None, None), size=(200, 50), pos_hint={'center_x': 0.7, 'y': 0.1})
        self.KillCode.bind(on_press=self.killcode_funct)
        self.add_widget(self.KillCode)

    def start_funct(self, instance):
        global brain_process
        if not brain_process:
            brain_process = subprocess.Popen(['python', 'Brain.py'])

    def stop_funct(self, instance):
        global brain_process
        if brain_process:
            brain_process.terminate()
            speak("Jarvis stopped.")
        else:
            speak("Jarvis is not running.")

    def killcode_funct(self, instance):
        global brain_process
        if brain_process:
            brain_process.terminate()
            speak("Termination Successful")
        else:
            speak("No process running")

class MyKivyApp(App):
    def build(self):
        Window.clearcolor = (0, 0, 0, 0)
        return Mylayout()

def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1
        r.energy_threshold = 300
        audio =  r.listen(source)
    try:
        print("Recognizing.....")
        query = r.recognize_google(audio, language='en-in')
        print("User said :", query,"\n")
        return query.lower()  # Always return the recognized query
    except Exception as e:
        print(e)
        print("Say that again please......")
        return "None"

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

if __name__ == "__main__":
    app = MyKivyApp()
    speak("Authentication Successful! Please say the manual override command to start Jarvis.")
    while True:
        cmd = takeCommand().lower()
        if 'manual override' in cmd:
            app.run()
        elif 'wake up Jarvis' in cmd:
            if not brain_process:
                brain_process = subprocess.Popen(['python', 'Brain.py'])
        elif 'kill code' in cmd:
            if brain_process:
                brain_process.terminate()
                speak("Termination Successful")
            else:
                speak("No process running")
            break
        elif 'you need a break' in cmd:
            if brain_process:
                brain_process.terminate()
                speak("Ok ma'am, if you need me, I'm just a command away! Just say wake up Jarvis.")
            else:
                speak("Jarvis inactive")
        
        else:
            print("nothing....")
