import subprocess
import speech_recognition as sr
import pyttsx3
from image_pop import imgPop


engine = pyttsx3.init('sapi5')
#check out what is sapi5
#using sapi5 to use voice API , which is api given by windows
voices = engine.getProperty('voices')
#print(voices[1].id)
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate',200)

def takeCommand():
    #It takes microphone input from the user and returns string output
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening.....")
        r.pause_threshold = 1
        r.energy_threshold = 300 # to avoid background noises
        #seconds of non spekaing audio before a  phrase is considered compelete
        audio =  r.listen(source)
    try:
        print("Recognizing.....")
        query = r.recognize_google(audio, language='en-in')
        print("User said :", query,"\n")  #*
    except Exception as e:
        print(e)
        print("Say that again please......")
        return "None"
    return query.lower()
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

if __name__=="__main__":
    brain_process = None

    imgPop()
    speak("Authentication Successful! Please say the hotword to access the control")

    while True:
        cmd = takeCommand().lower()

        if 'wake up jarvis' in cmd:
            # Start the Brain.py process if it's not already running
            if not brain_process:
                brain_process = subprocess.Popen(['python', 'Brain.py'])

        elif 'kill code' in cmd:
            # Terminate the Brain.py process if it's running
            if brain_process:
                brain_process.terminate()
            speak("Termination Successful")
            break
        elif 'you need a break' in cmd:
            if brain_process:
                brain_process.terminate()
                speak("ok ma'am, if you need me, I'm just a command away!")
                speak("Just say wake up jarvis")
            else:
                speak("Jarvis inactive")

        else:
            print("nothing....")